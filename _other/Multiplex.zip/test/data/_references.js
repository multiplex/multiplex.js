﻿/// <reference path="qunit.js" />
/// <reference path="../../src/javascript/multiplex.js" />